<?php

namespace App\Models;

use App\Enums\TestAccessType;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class TestAccess extends Model
{
    protected $fillable = [
        'type',
        'user_id',
        'group_id',
        'is_active',
        'student_chooses_subject',
        'nusqa_number',
        'student_chooses_nusqa',
        'question_count',
        'attempts_limit',
        'expires_at',
        'duration_minutes',
    ];

    protected $casts = [
        'type' => TestAccessType::class,
        'is_active' => 'boolean',
        'student_chooses_subject' => 'boolean',
        'student_chooses_nusqa' => 'boolean',
        'expires_at' => 'datetime',
    ];

    // ── Relationships ──────────────────────────────────────────────────────

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function group(): BelongsTo
    {
        return $this->belongsTo(Group::class);
    }

    /** Per-subject part configurations (up to 5 for ENT, 1 for Subject). */
    public function accessSubjects(): HasMany
    {
        return $this->hasMany(TestAccessSubject::class)->with(['subject', 'part']);
    }

    public function tests(): HasMany
    {
        return $this->hasMany(Test::class);
    }

    // ── Scopes ─────────────────────────────────────────────────────────────

    public function scopeForCurrentUser(Builder $query): Builder
    {
        $user = auth()->user();
        $userId = $user->id;
        $groupId = $user->group_id;

        return $query
            ->where('is_active', true)
            ->where(function (Builder $q) use ($userId, $groupId) {
                $q->where('user_id', $userId);
                if ($groupId) {
                    $q->orWhere('group_id', $groupId);
                }
            })
            ->where(function (Builder $q) {
                $q->whereNull('expires_at')->orWhere('expires_at', '>', now());
            });
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    public function isExpired(): bool
    {
        return $this->expires_at !== null && $this->expires_at->isPast();
    }

    public function targetLabel(): string
    {
        return $this->user?->name ?? $this->group?->title ?? '—';
    }
}
