@extends('layouts.admin')

@section('actions')
    <a href="{{ route('admin.users.index') }}" class="btn btn-outline btn-sm sm:px-5 sm:py-2.5 sm:text-sm">
        <x-icon name="arrow-left" class="w-4 h-4 shrink-0" />
        К пользователям
    </a>
@endsection

@section('content')

<div class="flex items-center gap-4 mb-5">
    <form method="GET" action="{{ route('admin.users.archive') }}" class="flex-1 max-w-sm">
        <div class="relative flex items-center gap-2">
            <div class="relative flex-1">
                <x-icon name="search" class="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted pointer-events-none" />
                <input
                    type="search"
                    name="search"
                    value="{{ request('search') }}"
                    placeholder="Поиск по имени, телефону, ИИН..."
                    class="pl-10"
                >
            </div>
            @if (request('search'))
                <a href="{{ route('admin.users.archive') }}" class="btn btn-ghost btn-sm shrink-0 text-text-muted hover:text-danger hover:bg-danger-light">
                    <x-icon name="x" class="w-4 h-4" />
                </a>
            @endif
        </div>
    </form>
</div>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th class="w-12 text-text-muted hidden sm:table-cell">ID</th>
                <th>Имя</th>
                <th>Телефон</th>
                <th>ИИН</th>
                <th>Роль</th>
                <th>Группа</th>
                <th>Удалён</th>
                <th class="w-16"></th>
            </tr>
        </thead>
        <tbody>
            @forelse ($users as $user)
                <tr>
                    <td class="text-text-muted text-xs font-mono hidden sm:table-cell">{{ $user->id }}</td>
                    <td class="font-semibold">{{ $user->name }}</td>
                    <td class="font-mono">{{ $user->login }}</td>
                    <td class="font-mono text-text-muted">{{ $user->iin }}</td>
                    <td>
                        @if ($user->role === \App\Enums\Role::Admin)
                            <span class="badge badge-primary">{{ $user->role->title() }}</span>
                        @else
                            <span class="badge badge-info">{{ $user->role->title() }}</span>
                        @endif
                    </td>
                    <td class="text-text-muted">{{ $user->group?->title ?? '—' }}</td>
                    <td class="text-text-muted text-sm">{{ $user->deleted_at->format('d.m.Y H:i') }}</td>
                    <td>
                        <div class="flex items-center gap-1.5">
                            <x-btn.restore :route="route('admin.users.restore', $user)" />
                        </div>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="8" class="text-center text-text-muted py-12">
                        @if (request('search'))
                            По запросу «{{ request('search') }}» в архиве ничего не найдено.
                        @else
                            Архив пуст.
                        @endif
                    </td>
                </tr>
            @endforelse
        </tbody>
    </table>

    @if ($users->hasPages())
        <div class="px-5 py-4 border-t border-border">
            {{ $users->links() }}
        </div>
    @endif
</div>

@endsection
